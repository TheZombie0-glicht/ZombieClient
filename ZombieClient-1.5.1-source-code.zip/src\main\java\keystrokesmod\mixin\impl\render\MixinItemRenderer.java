package keystrokesmod.mixin.impl.render;

import keystrokesmod.mixin.interfaces.IMixinItemRenderer;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.utility.Utils;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public class MixinItemRenderer implements IMixinItemRenderer {
    private ItemStack originalItemToRender;
    private boolean itemAnimationTransformPushed;
    @Shadow
    private ItemStack itemToRender;
    public boolean cancelUpdate = false;
    public boolean cancelReset = false;
    @Shadow
    private float equippedProgress;
    @Shadow
    private float prevEquippedProgress;

    @Inject(method = "renderItemInFirstPerson", at = @At("HEAD"))
    private void modifyRenderItemPre(float p_renderItemInFirstPerson_1_, CallbackInfo info) {
        originalItemToRender = itemToRender;
        itemToRender = Utils.getSpoofedItem(originalItemToRender);
        itemAnimationTransformPushed = ModuleManager.itemAnimations != null
                && ModuleManager.itemAnimations.beginFirstPersonRender(p_renderItemInFirstPerson_1_);
    }

    @Inject(method = "renderItemInFirstPerson", at = @At("RETURN"))
    private void modifyRenderItemPost(float p_renderItemInFirstPerson_1_, CallbackInfo info) {
        if (itemAnimationTransformPushed) {
            net.minecraft.client.renderer.GlStateManager.popMatrix();
            itemAnimationTransformPushed = false;
        }
        itemToRender = originalItemToRender;
    }

    @Inject(method = "updateEquippedItem", at = @At("HEAD"), cancellable = true)
    private void onUpdateEquippedItem(CallbackInfo ci) {
        if (cancelUpdate) {
            cancelUpdate = false;
            equippedProgress = 1.0F;
            prevEquippedProgress = 1.0f;
            ci.cancel();
        }
    }

    @Inject(method = "resetEquippedProgress", at = @At("HEAD"), cancellable = true)
    public void injectResetEquippedProgress(CallbackInfo ci) {
        if (cancelReset) {
            cancelReset = false;
            equippedProgress = 1.0F;
            prevEquippedProgress = 1.0f;
            ci.cancel();
        }
    }

    @Inject(method = "resetEquippedProgress2", at = @At("HEAD"), cancellable = true)
    public void injectResetEquippedProgress2(CallbackInfo ci) {
        if (cancelReset) {
            cancelReset = false;
            equippedProgress = 1.0F;
            prevEquippedProgress = 1.0f;
            ci.cancel();
        }
    }

    @Override
    public void setCancelUpdate(boolean cancel) {
        this.cancelUpdate = cancel;
    }

    @Override
    public void setCancelReset(boolean reset) {
        this.cancelReset = reset;
    }
}
